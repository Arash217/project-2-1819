(function(s){
s.data["1248_505"]={};
for(var i=0;i<s.listeners.length;i++){
s.listeners[i]("1248_505");
}
})(_st.segmenting);