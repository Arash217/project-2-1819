(function(s){
s.data["1248_458"]={"favoriteElectricInterest":"","favoritePrivateLease":"","favoriteDealer":"","engagementScore":"3","leadscore":"true","favoriteSection":"","favoriteBrand":"volkswagen","favoriteService":"","lastAction":"","favoriteAction":"","favoriteModel":"","tallyTotals":"{\"brand\":3}","engagements":"{\"brand\":{\"volkswagen\":3}}","favoriteModelGroup":"","favoriteModelStyle":"","favoriteOccasion":"","favoriteElectricModel":"","lastTallies":"{\"brand\":[\"volkswagen\",\"volkswagen\",\"volkswagen\"]}"};
s.data["1248_411"]=false;
s.data["1248_454"]={"favoriteElectricInterest":"","favoritePrivateLease":"","engagementScore":"3","leadscore":"true","favoriteSection":"","favoriteService":"","lastAction":"","favoriteModel":"","tallyTotals":"{\"brand\":3}","engagements":"{\"brand\":{\"volkswagen\":3}}","favoriteModelGroup":"","favoriteModelStyle":"","favoriteOccasion":"","favoriteElectricModel":"","lastTallies":"{\"brand\":[\"volkswagen\",\"volkswagen\",\"volkswagen\"]}"};
for(var i=0;i<s.listeners.length;i++){
s.listeners[i]("1248_458","1248_411","1248_454");
}
})(_st.segmenting);