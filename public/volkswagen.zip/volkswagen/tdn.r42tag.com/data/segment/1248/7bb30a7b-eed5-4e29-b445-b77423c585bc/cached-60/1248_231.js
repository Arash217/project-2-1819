(function(s){
s.data["1248_231"]=false;
for(var i=0;i<s.listeners.length;i++){
s.listeners[i]("1248_231");
}
})(_st.segmenting);